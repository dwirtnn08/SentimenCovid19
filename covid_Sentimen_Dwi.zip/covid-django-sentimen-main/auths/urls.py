from django.urls import path
from auths.views import signin, register, dashboard, signout,list_tweet_file, \
    upload_tweet_file, detail_tweet_file

from django.conf import settings
from django.conf.urls.static import static

app_name = 'auths'


urlpatterns = [
    path('signin/', signin, name="signin"),
    path('daftar098098409039q740973097403974097/', register, name="register"),
    path('dashboard/',dashboard,name="dashboard"),
    path('signout/',signout,name="signout"),
    # path('upload/',simple_upload,name="upload"),
    # path('view/',view_tweet,name="view"),

    path('list-tweet-file/', list_tweet_file, name='list-tweet-file'),
    path('upload-tweet-file/', upload_tweet_file, name='upload-tweet-file'),
    path('detail-tweet-file/<int:pk>/', detail_tweet_file, name='detail-tweet-file'),
]

# urlpatterns=urlpatterns+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)