
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage

from django.shortcuts import render, redirect, get_object_or_404
from django.template.defaultfilters import lower

from auths.forms import SigninForm, RegisterForm, TweetExcelForm, TweetFileForm
from . import prepocessing

from .models import Tweet, TweetFile, TweetPost
from .prepocessing import Sentys, SLANKWORDS,knn
from .resources import TweetResource
from django.contrib import messages
from tablib import Dataset
from django.http import HttpResponse

from .models import Tweet

FILE_TYPE = ['xlsx']

def signin(request):
    form = SigninForm()

    if request.method == 'POST':
        form = SigninForm(request.POST)
        if form.is_valid():
            user = authenticate(request,
                                username=form.cleaned_data['username'],
                                password=form.cleaned_data['password'])
            if user is not None:
                login(request, user)
                return redirect('auths:dashboard')
            else:
                return render(request, 'auths/invalid_login.html')

    return render(request, 'auths/signin.html', {'form': form})


def register(request):
    form=RegisterForm()
    if request.method == 'POST':
        form=RegisterForm(request.POST)

        if form.is_valid():
            username=form.cleaned_data.get('username')
            password=form.cleaned_data.get('password')
            email=form.cleaned_data.get('email')
            first_name=form.cleaned_data.get('first_name')
            last_name=form.cleaned_data.get('last_name')
            User.objects.create_user(username,email,password,first_name=first_name,last_name=last_name)

            return redirect('auths:signin')
    else:
        return render(request, 'auths/register.html', {'form': form})

    return render(request, 'auths/register.html',{'form':form})

def index(request):
    return render(request,'auths/index.html')


@login_required(login_url='/auths/signin')
def dashboard(request):
    return render(request, 'auths/dashboard.html')


@login_required(login_url='/auths/signin')
def list_tweet_file(request):
    tweet_files = TweetFile.objects.filter(user=request.user).order_by('-id')
    page = request.GET.get('page', 1)
    paginator = Paginator(tweet_files, 10)

    try:
        tweet_files = paginator.page(page)
    except PageNotAnInteger:
        tweet_files = paginator.page(1)
    except EmptyPage:
        tweet_files = paginator.page(paginator.num_pages)

    return render(request, 'auths/list-tweet-file.html', {'tweet_files': tweet_files})


@login_required(login_url='/auths/signin')
def upload_tweet_file(request):
    form = TweetFileForm()
    if request.method == 'POST':
        tff = request.FILES['tweet_file']

        form = TweetFileForm(request.POST, request.FILES)
        if form.is_valid():
            data = form.save(commit=False)
            data.user = request.user
            data.save()


            sp = Sentys(tff, ['posting_id', 'user_name', 'tweet','sentiment_manual'], SLANKWORDS)
            sp.execute()
            df = sp.get_data_frame()
            result = sp.get_sentiment_result()
            data.status = result[0]
            data.sentiment = result[1]
            data.accuracy, classification = sp.knn()

            data.macroavg_precision = classification['macro avg']['precision']
            data.macroavg_recall = classification['macro avg']['recall']
            data.macroavg_f1score = classification['macro avg']['f1-score']
            data.macroavg_support = classification['macro avg']['support']

            # data.weightedavg_precision = classification['weighted avg']['precision']
            # data.weightedavg_recall = classification['weighted avg']['recall']
            # data.weightedavg_f1score = classification['weighted avg']['f1-score']
            # data.weightedavg_support = classification['weighted avg']['support']
            #
            # data.positive_precision = classification['Positive']['precision']
            # data.positive_recall = classification['Positive']['recall']
            # data.positive_f1score = classification['Positive']['f1-score']
            # data.positive_support = classification['Positive']['support']
            #
            # data.neutral_precision = classification['Neutral']['precision']
            # data.neutral_recall = classification['Neutral']['recall']
            # data.neutral_f1score = classification['Neutral']['f1-score']
            # data.neutral_support = classification['Neutral']['support']
            data.save()
            # messages.success(request, 'File upload successful')
            data_tweets = []
            for x in df.values.tolist():
                data_tweets.append(TweetPost(
                    tweet_file=data,
                    user=request.user,
                    posting_id=x[0],
                    account=x[1],
                    tweet=x[2],
                    sentiment_manual=x[3],
                    # polarity=x[5],
                    # subjective=x[6],
                    sentiment=x[8]
                ))
            print (df)
            TweetPost.objects.bulk_create(data_tweets)

            return redirect('auths:detail-tweet-file', pk=data.pk)

    return render(request, 'auths/upload-tweet-file.html', {'form': form})


@login_required(login_url='/auths/signin')
def detail_tweet_file(request, pk):
    tweet_file = get_object_or_404(TweetFile, pk=pk)
    tweet_posts = TweetPost.objects.filter(tweet_file=tweet_file)
    return render(request,
                  'auths/detail-tweet-file.html',
                  {'tweet_file': tweet_file, 'tweet_posts': tweet_posts})


# @login_required(login_url='/auths/signin')
# def simple_upload(request):
#     if request.method == 'POST':
#         person_resource = TweetResource()
#         dataset = Dataset()
#         new_persons = request.FILES['xls']
#
#         imported_data = dataset.load(new_persons.read(), format='xlsx')
#         # print(imported_data)
#         data_tweets = []
#         for data in imported_data:
#             data_tweets.append(Tweet(
#                 data[0],
#                 data[1],
#                 data[2],
#                 data[3]
#             ))
#         Tweet.objects.bulk_create(data_tweets)
#         form = TweetExcelForm(request.POST, request.FILES)
#         if form.is_valid():
#             obj_tweet_excel = form.save()
#         # if imported_data not in FILE_TYPE:
#         #     return render(request, 'auths/error_404.html')
#     return render(request, 'auths/upload.html')
#
# @login_required(login_url='/auths/signin')
# def view_tweet(request):
#     obj = Tweet.objects.all()
#     context={
#         'obj': obj
#     }
#     return render(request,'auths/viewdata.html', context)

# def preproses(request, id):
#     tweets = Tweet.objects.get(id=id)
#     slank = prepocessing.slank(tweets.abstract)
#     remove_numbers = prepocessing.remove_pattern(slank)
#     remove_punctuation = prepocessing.remove(remove_numbers)
#     remove_whitespace = prepocessing.clean_tweets(remove_punctuation)
#     remove_stopwords = prepocessing.remove_punct(remove_whitespace)
#     return render(request, "auths/prepocessing.html",{
#                 'Tweet': tweets,
#                 'lower':lower,
#                 'remove_numbers': remove_numbers,
#                 'remove_punctuation': remove_punctuation,
#                 'remove_whitespace': remove_whitespace,
#                 'remove_stopwords': remove_stopwords
#             })

def signout(request):
    logout(request)
    return redirect('auths:signin')
