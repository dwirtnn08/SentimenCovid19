import pandas as pd
import numpy as np
import nltk
import string
import re
from nltk.tokenize import word_tokenize #import library nltk - tokenize
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory #import library sastrawi untuk
from sklearn.metrics import classification_report
from textblob import TextBlob
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.neighbors import KNeighborsClassifier
import np

from nltk.corpus import stopwords
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
from nltk.tokenize import TweetTokenizer
from cleantext import clean
from nltk.stem import PorterStemmer

# np = 0
# nn = 0
# n = 0

# Emoji Senang
emoticons_happy= set([
    ':-)',':)',';)',':o)',':]',':3',':c)',':>','=]','8)','=}',
    ':^)',':-D',':D','8-D','8D','x-D','XD','X-D','xD','wkwkwkw','haha'
])

# Emoji Sedih
emoticons_sad =set([
    ':l',':-/','>:/',':S','>:]',':@',':-(',':[',':-||','-l',':<',
    ':-[',':-<','=\\','=/','>:(',':(','>_<','hhh'
])

# all emoticons (hapy+sad)
emoticons = emoticons_happy.union(emoticons_sad)

SLANKWORDS = {
    "skrg":"sekarang",
    "ni":"ini","tp":"tetapi","ms":"masih",
    "iso":"bisa",
    "syaanggg":"sayang",
    "sebelom":"sebelum",
    "tbtb":"lalu",
    "muali":"mulai",
    "tak":"tidak",
    "yt":"youtube","nimbrung":"mengikuti","ngasal":"asal",
    "sampe":"sampai","hp":"handphone","aja":"saja","nihhh":"nih","pastiii":"pasti","kagaa":"tidak","blm":"belum",
    "anjim":"anjing",
    "yg":"yang",
    "diyt":"di youtube",
    "gk":"tidak",
    "aing":"saya",
    "hny":"hanya",
    "dr":"dari",
    "gak":"tidak",
    "plg":"paling",
    "sdh":"sudah",
    "adlh":"adalah",
    "vs":"versus",
    "ndak":"tidak",
    "ntr":"nanti",
    "klo":"kalau",
    "dlu":"dulu",
    "krn":"karena","kadrun":"kadal gurun",
    "gw":"saya","sssaja":"saja",
    "gua":"saya",
    "gmn":"bagaimana",
    "tdk":"tidak","kaga":"tidak",
    "kpd":"kepada",
    "unk":"untuk",
    "t4gar":"tagar",
    "lg":"lagi",
    "rs":"rumah sakit",
    "trus":"terus","go out:(":"pergi sad",
    "w":"saya",
    "udah":"sudah","susaaah":"susah","bgt":"sangat",
    "dsr":"dasar",
    "srh":"suruh",
    "dg":"dengan","skuyy":"","lgsg":"",
    "jg":"juga","trs":"terus",
    "covid-19":"korona",
    "sars-cov-2":"korona",
    "tgr":"tagar",
    "aq":"saya","ssaja":"saja",
    "gr2":"karena","dgn":"dengan",
    "kovid-19":"korona",
    "gue":"saya","alloh":"Allah",
    "jd":"jadi","plis jng":"mohon jangan",
    "gpp":"tidak apa","onlen":"online",
    "ato":"atau",
    "ga":"tidak","hhhhhh":"sad",
    "engtidak":"tidak","xe x xa":"",
    "covid 19":"korona","kiyowoo":"imut",
    "kelar":"selesai",
    "kek":"seperti",
    "pankapanlah":"nanti","uu":"undang-undang",
    "pesepedamarak":"pesepeda marak",
    "cepatt":"cepat","drpd":"daripada",
    "ntar":"nanti","sampek":"sampai","udh":"sudah","grgr":"karena","ngtidak":"tidak","ak":"saya","tpi":"tetapi","knp":"kenapa"
}


class Sentys:
    TWEET = 'tweet'
    DATA_SLANK = None
    SENTIMENTAL_POLARITY = 'POLARITY'
    SENTIMENTAL_SUBJECTIVE = 'SUBJECTIVE'
    SENTIMENTAL_SENTIMENT = 'SENTIMENT'
    SENTIMENTAL_THRESHOLD = 0

    def __init__(self, excel, fields, slankwords):
        self.__excel = excel
        self.__fields = fields
        self.__data = None
        self.__data_frame = None
        self.__full_text = None
        self.__total_polarity = 0
        Sentys.DATA_SLANK = slankwords

    def execute(self):
        self.__nltk_dependency()
        self.__build_data()
        self.__build_data_frame()
        self.__build_remove_slank()
        self.__build_remove_patterns()
        self.__build_clean_tweet()
        self.__build_sentiment()

    def __build_data(self):
        self.__data = pd.read_excel(self.__excel,
                                    header=None,
                                    names=self.__fields)

    def __build_data_frame(self):
        self.__data_frame = pd.DataFrame(self.__data)

    def __build_remove_slank(self):
        self.__full_text = self.__data_frame[Sentys.TWEET].values.tolist()  # masukan data kedalam list

        for index, text in enumerate(self.__full_text):
            text = text.lower()
            splitlines = word_tokenize(text)
            for word in splitlines:
                if word in Sentys.DATA_SLANK:
                    text = text.replace(word, str(Sentys.DATA_SLANK[word]));
                    self.__full_text[index] = text

        self.__data_frame['slank_text'] = self.__full_text

    @staticmethod
    def __vectorize_remove_patterns(tweet, pattern):
        r = re.findall(pattern, tweet)

        for i in r:
            tweet = re.sub(i, '', tweet)

        return tweet

    def __build_remove_patterns(self):
        self.__data_frame['remove_user'] = np.vectorize(
            Sentys.__vectorize_remove_patterns
        )(self.__data_frame['slank_text'], "@[\w]*")

    @staticmethod
    def __clean_tweet(tweet):

        stopwords_indonesia = stopwords.words('indonesian')
        factory = StemmerFactory()
        stemmer = factory.create_stemmer()

        data = clean(tweet.strip(),
                     fix_unicode=False,  # fix various unicode errors
                     to_ascii=True,  # transliterate to closest ASCII representation
                     lower=True,  # lowercase text
                     no_line_breaks=False,  # fully strip line breaks as opposed to only normalizing them
                     no_urls=True,  # replace all URLs with a special token
                     no_emails=True,  # replace all email addresses with a special token
                     no_phone_numbers=True,  # replace all phone numbers with a special token
                     no_numbers=True,  # replace all numbers with a special token
                     no_digits=True,  # replace all digits with a special token
                     no_currency_symbols=True,  # replace all currency symbols with a special token
                     no_punct=True,  # remove punctuations
                     no_emoji=True,
                     replace_with_punct="",
                     replace_with_digit="",
                     replace_with_number="",
                     replace_with_url='',
                     normalize_whitespace=False,
                     )

        #         for word in tweet_tokens:
        #             if(word not in stopwords_indonesia and #remove stropwords
        #                   word not in emoticons and #removes emoticon
        #                       word not in string.punctuation): #remove punctuation
        #                  # tweets_clean.append(word)
        #                 stem_word=stemmer.stem(word) #remove word
        #                 tweets_clean.append(stem_word)

        # return str(stemmer.stem(data))
        return data

    def __sentimental(self, text, key):

        analysis = TextBlob(text)
        self.__total_polarity += analysis.polarity

        if key == Sentys.SENTIMENTAL_SUBJECTIVE:
            return analysis.sentiment[1]
        elif key == Sentys.SENTIMENTAL_POLARITY:
            return analysis.polarity
        elif key == Sentys.SENTIMENTAL_SENTIMENT:
            if analysis.polarity == Sentys.SENTIMENTAL_THRESHOLD:
                return 'Neutral'
            elif analysis.polarity > Sentys.SENTIMENTAL_THRESHOLD:
                return 'Positive'
            else:
                return 'Negative'

    def __build_clean_tweet(self):
        self.__data_frame['tweet'] = self.__data_frame['remove_user'].apply(
            lambda x: Sentys.__clean_tweet(x)
        )

        self.__data_frame.drop_duplicates(subset="tweet", keep='first', inplace=True)
        self.__data_frame.sort_values("tweet", inplace=True)

    def __build_sentiment(self):
        self.__data_frame['polarity'] = self.__data_frame['tweet'].apply(
            lambda x: self.__sentimental(x, Sentys.SENTIMENTAL_POLARITY)
        )
        self.__data_frame['subjective'] = self.__data_frame['tweet'].apply(
            lambda x: self.__sentimental(x, Sentys.SENTIMENTAL_SUBJECTIVE)
        )
        self.__data_frame['sentiment'] = self.__data_frame['tweet'].apply(
            lambda x: self.__sentimental(x, Sentys.SENTIMENTAL_SENTIMENT)
        )

    def get_data_frame(self):
        return self.__data_frame

    def get_sentiment_result(self):
        if self.__total_polarity / 100 > 0:
            return "Positive", self.__total_polarity / 100

        elif self.__total_polarity / 100 == 0:
            return "Netral", self.__total_polarity / 100

        elif self.__total_polarity / 100 < 0:
            return "Negative", self.__total_polarity / 100

    def save(self, name):
        return self.__data_frame.to_csv(f'{name}.csv', encoding='utf8', index=True)

    def save_db(self, orm):
        pass

    def knn(self):
        # print(filename)

        X = self.__data_frame.tweet
        y = self.__data_frame.sentiment

        # Using CountVectorizer to convert text into tokens/features
        vect = CountVectorizer(stop_words='english', ngram_range=(1, 1), max_df=0.95, min_df=1)
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)

        # Using training data to transform text into counts of features for each message
        vect.fit(X_train)
        X_train_dtm = vect.transform(X_train)
        X_test_dtm = vect.transform(X_test)

        # Accuracy using KNN Model
        KNN = KNeighborsClassifier(n_neighbors=3)
        KNN.fit(X_train_dtm, y_train)
        y_pred = KNN.predict(X_test_dtm)
        print('\nK Nearest Neighbors (NN = 3)')
        print('Accuracy Score: ', metrics.accuracy_score(y_test, y_pred), sep='')
        print('Confusion Matrix: ', metrics.confusion_matrix(y_test, y_pred), sep='\n')
        print(classification_report(y_test, y_pred, output_dict=True))
        return metrics.accuracy_score(y_test, y_pred), classification_report(y_test, y_pred, output_dict=True)

    def __nltk_dependency(self):
        nltk.download('punkt')
        nltk.download('stopwords')

# def count_sentiment(filename):
#     data = pd.read_csv(filename)
#     data_info = data.polarity.value_counts()
#     l = len(data)
#     print("Neutral :" + str((data_info['Neutral'] / l) * 100) + " %")
#     print("Positive :" + str((data_info['Positive'] / l) * 100) + " %")
#     print("Negative :" + str((data_info['Negative'] / l) * 100) + " %")
#     return(str((data_info['Neutral'] / l) * 100),str((data_info['Positive'] / l) * 100),str((data_info['Negative'] / l) * 100))

def knn(filename, fields):
    print(filename)
    data = pd.read_csv(filename, names=fields, sep='|')
    X = data.tweet
    y = data.sentiment

    # Using CountVectorizer to convert text into tokens/features
    vect = CountVectorizer(stop_words='english', ngram_range=(1, 1), max_df=0.95, min_df=1)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)

    # Using training data to transform text into counts of features for each message
    vect.fit(X_train)
    X_train_dtm = vect.transform(X_train)
    X_test_dtm = vect.transform(X_test)

    # Accuracy using KNN Model
    KNN = KNeighborsClassifier(n_neighbors=3)
    KNN.fit(X_train_dtm, y_train)
    y_pred = KNN.predict(X_test_dtm)
    print('\nK Nearest Neighbors (NN = 3)')
    print('Accuracy Score: ', metrics.accuracy_score(y_test, y_pred), sep='')
    print('Confusion Matrix: ', metrics.confusion_matrix(y_test, y_pred), sep='\n')


# knn('result.csv', ['tweet', 'sentiment'])