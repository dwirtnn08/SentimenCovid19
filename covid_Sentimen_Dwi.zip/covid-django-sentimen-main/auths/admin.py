from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from .models import Tweet, TweetExcel, TweetPost, TweetFile


# Register your models here.

@admin.register(Tweet)
class TweetAdmin(ImportExportModelAdmin):
    list_display = ('id','posting_id','user_name','tweet')

@admin.register(TweetExcel)
class TweetExcelAdmin(admin.ModelAdmin):
    list_display = ('id','xls')




@admin.register(TweetPost)
class TweetExcelAdmin(admin.ModelAdmin):
    list_display = ('tweet_file','user', 'posting_id','account', 'sentiment_manual','sentiment')
    list_filter = ['tweet_file']

@admin.register(TweetFile)
class TweetExcelAdmin(admin.ModelAdmin):
    list_display = ('user','tweet_file','positive','negative','netral')

