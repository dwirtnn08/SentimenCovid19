from Sastrawi.Stemmer.StemmerFactory import StemmerFactory #import library sastrawi untuk
from textblob import TextBlob
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.neighbors import KNeighborsClassifier
import pandas as pd

data = pd.read_csv('data_korona_sentimen.csv',names=['Tweet','sentimen'])
X = data.Tweet
y = data.sentimen

#Using CountVectorizer to convert text into tokens/features
vect = CountVectorizer(stop_words='english', ngram_range = (1,1), max_df = 0.95, min_df = 1)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size= 0.3)

#Using training data to transform text into counts of features for each message
vect.fit(X_train)
X_train_dtm = vect.transform(X_train)
X_test_dtm = vect.transform(X_test)

#Accuracy using KNN Model
KNN = KNeighborsClassifier(n_neighbors =3)
KNN.fit(X_train_dtm, y_train)
y_pred = KNN.predict(X_test_dtm)
print('\nK Nearest Neighbors (NN = 3)')
print('Accuracy Score: ',metrics.accuracy_score(y_test,y_pred),sep='')
print('Confusion Matrix: ',metrics.confusion_matrix(y_test,y_pred), sep = '\n')

from sklearn.metrics import classification_report
print(classification_report(y_test,y_pred))