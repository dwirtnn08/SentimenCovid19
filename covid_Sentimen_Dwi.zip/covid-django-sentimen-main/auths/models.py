from django.db import models


class TweetFile(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name='owner')
    tweet_file = models.FileField(upload_to='documents/%Y/%m/%d')
    status = models.CharField(max_length=100, blank=True)
    sentiment = models.FloatField(default=0.0)
    positive = models.FloatField(default=0.0)
    negative = models.FloatField(default=0.0)
    netral = models.FloatField(default=0.0)

    accuracy = models.FloatField(default=0.0)

    macroavg_precision = models.FloatField(default=0.0)
    macroavg_recall = models.FloatField(default=0.0)
    macroavg_f1score = models.FloatField(default=0.0)
    macroavg_support = models.FloatField(default=0.0)

    weightedavg_precision = models.FloatField(default=0.0)
    weightedavg_recall = models.FloatField(default=0.0)
    weightedavg_f1score = models.FloatField(default=0.0)
    weightedavg_support = models.FloatField(default=0.0)

    neutral_precision = models.FloatField(default=0.0)
    neutral_recall = models.FloatField(default=0.0)
    neutral_f1score = models.FloatField(default=0.0)
    neutral_support = models.FloatField(default=0.0)

    positive_precision = models.FloatField(default=0.0)
    positive_recall = models.FloatField(default=0.0)
    positive_f1score = models.FloatField(default=0.0)
    positive_support = models.FloatField(default=0.0)

    def __str__(self):
        return self.tweet_file.name.split('/')[-1]


class TweetPost(models.Model):
    tweet_file = models.ForeignKey(TweetFile, on_delete=models.CASCADE, related_name='tweetpost_file')
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name='tweetpost_user')
    posting_id = models.CharField(max_length=35)
    account = models.CharField(max_length=20)
    tweet = models.TextField()
    polarity = models.FloatField(default=0.0)
    subjective = models.FloatField(default=0.0)
    sentiment_manual=models.CharField(max_length=50, blank=True, null=True)
    sentiment = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return self.tweet


class Tweet(models.Model):
    # created_at = models.DateTimeField(['%Y-%m-%d %H:%M:%S'])
    posting_id = models.CharField(max_length=35)
    user_name = models.CharField(max_length=20)
    tweet = models.CharField(max_length=120)

    objects = models.Manager()



class TweetExcel(models.Model):
    xls = models.FileField(upload_to='documents/%Y/%m/%d')

    def __str__(self):
        return ''