from django import forms

from auths.models import TweetExcel, TweetFile


class SigninForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)

class RegisterForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)
    email= forms.CharField()
    first_name=forms.CharField()
    last_name=forms.CharField()

class TweetExcelForm(forms.ModelForm):
    xls=forms.FileField(label='select a file')

    class Meta:
        model=TweetExcel
        fields='__all__'


class TweetFileForm(forms.ModelForm):
    class Meta:
        model = TweetFile
        fields = [
            'tweet_file',
        ]